document.querySelector("#operator").addEventListener("change", calculate);
document.querySelector("#operator").addEventListener("mouserover", calculate);

function calculate(event) {
  debugger;
  const value1 = document.querySelector("#operand1");
  const value2 = document.querySelector("#operand2");
  const inputs = document.querySelectorAll("[type=text]");

  if (value1.value != "" && value2.value != "") {
    const result = document.querySelector("#result");
    const operator = event.target.value;
    let output = 0;
    switch (operator) {
      case "add":
        output = parseFloat(value1.value) + parseFloat(value2.value);
        break;
      case "sub":
        output = parseInt(value1.value) - parseInt(value2.value);
        break;
      case "mul":
        output = parseInt(value1.value) * parseInt(value2.value);
        break;
      case "divison":
        output = parseInt(value1.value) / parseInt(value2.value);
        break;
    }
    result.innerHTML = `${operator}  result of operand 1=> ${value1.value} and operand 2:=> ${value2.value} = <h3>${output}</h3>`;
    //value1.value="";
    // value2.value="";
  } else {
    alert("INVALID INPUT");
  }

  alert(eval("3.1+5.2"));
}




function student(name, rollnumber, score){


return function(){
    console.log(`${name} ${rollnumber} ${score}`);
}
}
student('john', '1234', 98);


class Student {
    constructor(name, rollnumber, score){
        this.name=name;
        this.rollnumber=rollnumber;
        this.score=score;
    }
    printDetails(){
        console.log(`${this.name} ${this.rollnumber} ${this.score}`);
    }
    getScore(){
        console.log(`SCORE IS ${this.score} percent`); // "SCORE IS" + this.score + "percentage"

    }
}

let mayank=new Student('mayank', '1234', 98);
let john=new Student('john', '123445', 98);
let brad=new Student('brad', '1234', 98);