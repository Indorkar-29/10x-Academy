

class Shopping {

static CURRENCY='INR'//PUBLIC PROPERTY/FIELD

static #MARGIN="2"//STATIC FIELDS ARE USING FOR FIXED CONFIGURATION

static getCurrency(){ //Static fields can only be accessed by static methods.
    return this.CURRENCY;
}


  constructor(name, price) {
    this._itemName = name;
    this._itemPrice = price;
  }
  init() {
    this.total = parseInt(document.querySelector("#total").innerText);
    this.tbody = document.querySelector("table tbody");
  }
  get TotalValue() {
    return (this.total = this.total + (this.total * this.tax) / 100);
  }
  get getTax() {
    //GETTER METHOD USED to have access of classes variable/properties/attributes
    this.tax;
  }
  set setTax(
    x //SETTER MOTHOD used to set or update values of classes variable/properties/attributes
  ) {
    this.tax = x;
  }

  addItem() {
    
    if (this._itemName != "" && this._itemPrice != "") {
      const row = document.createElement("tr");
      const itemnameTD = document.createElement("td");
      const itempriceTD = document.createElement("td");
      itempriceTD.classList.add("item-price");
      itemnameTD.innerText = this._itemName;
      itempriceTD.innerText = this._itemPrice +" "+ Shopping.getCurrency();//THIS REFERS TO SHOPPING
      row.appendChild(itemnameTD);
      row.appendChild(itempriceTD);
      this.tbody.appendChild(row);
      this.calculateTotal();
    }
  }
  calculateTotal() {
    const allPrice = document.querySelectorAll(".item-price");
    if (allPrice.length == 10) {
      document.querySelector("#add-item").removeEventListener("click");
    }
    this.total = 0;
    for (let itemprice of allPrice) {
      this.total += parseInt(itemprice.innerText);
    }
    document.querySelector("#total").innerText = this.total;
  }
  reset(itemName, itemPrice) {
    itemName.value = "";
    itemPrice.value = "";
  }
}

function addIntoShoppingCart() {
  const itemname = document.querySelector("#name");
  const itemprice = document.querySelector("#price");
  let item = new Shopping(itemname.value, itemprice.value);
  item.init();
  item.addItem();
  item.setTax = 15; //CALLING of SETTER METHOD
  console.log("TOTAL VALUE OF YOUR SHOPPING CART IS:-" + item.TotalValue);
  document.querySelector("#taxtotal").innerText = item.TotalValue;
  //   item.TotalValue=100;
  //   console.log("TOTAL VALUE OF YOUR SHOPPING CART IS:-"+item.TotalValue)

  item.reset(itemname, itemprice);
}

document
  .querySelector("#add-item")
  .addEventListener("click", addIntoShoppingCart);
