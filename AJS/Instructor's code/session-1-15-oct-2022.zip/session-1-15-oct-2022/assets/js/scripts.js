//DOM
//ACCESS THE NODE
//STORE THE REF OF THAT NODE

//APPLY CSS
//ADD/REMOVE Attributes
//ADD/REMOVE CLASSES
//DOM Manipulation,
//DOM Events (FOCUS, CHANGE[RADIO, CHECKBOX], KEYUP, CLICK, BLUR, HOVER, SUBMIT, MOUSEOUT)
//Creating and Adding html elements to page

const ListItem = document.querySelector("#last-item"); //RETURN the first instance of an element
console.log("LI querySelector:-");
console.log(ListItem);
//background-color

ListItem.style.boxShadow = "5px 5px 15px gray";
const styles = "box-shadow:5px 5px 15px gray;background-color:lightblue";
ListItem.setAttribute("style", styles);
ListItem.setAttribute("abc", "xyz"); //FIRST PARAM--> ATTRIBUTE NAME and SECOND PARAM--> ATTRIBUTE VALUE
setTimeout(function () {
  ListItem.removeAttribute("style");
  ListItem.classList.remove("bolder-text");
}, 5000);
//ADD CLASS
ListItem.classList.add("bolder-text");

const ListItems = document.querySelectorAll("#last-item"); //RETURN the all instance of an elements
console.log("LI querySelectorAll:-");
console.log(ListItems); //

function createElement(event) {
  debugger;
  const numberOfELement = document.querySelector(".input-text");
  const orderedList = document.querySelector("ol");
  const listCount = document.querySelectorAll("ol li").length;
  for (let i = 0; i < numberOfELement.value; i++) {
    const listitem1 = document.createElement("li");
    listitem1.classList.add("new-item");

    listitem1.innerText = "OL ITEM " + (listCount + (i + 1));
    orderedList.appendChild(listitem1);
  }
  numberOfELement.value = "";
}
//ASSIGNMNET 4 HINT
/*
//<table></table>


//HOW to ADD NEW row and cells in table;
const row=document.createElement('tr');//<tr></tr>
const nameTd=document.createElement('td');//<tr></tr>
const priceTd=document.createElement('td');//<tr></tr>
priceTd.classList.add("price-value");
row.appendChild(nameTd);
row.appendChild(priceTd);
document.querySelector('table').appendChild(row);

//get all price value
const allPriceValues=document.querySelectorAll('.price-value');
let total=0;
for(let i=0; i<allPriceValues.length;i++){
total+=parseInt(document.querySelector(allPriceValues[i]).innerText);
}

*/

const btn = document.querySelector("#create-element");
btn.addEventListener("click", createElement);

document.querySelector(".phone").addEventListener("blur", function (event) {
  debugger;
  document.querySelector("#number").innerText = event.target.value;
});
