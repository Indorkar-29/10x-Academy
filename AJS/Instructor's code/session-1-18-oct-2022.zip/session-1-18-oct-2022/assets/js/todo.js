const todoSubmit = document.querySelector("#add-todo");
const todos = document.getElementById("todos");
todoSubmit.addEventListener("click", addTodo);
function addTodo() {
  fetch("https://jsonplaceholder.typicode.com/posts", {
    // fetch("SERVER URL", options)
    method: "POST",
    body: JSON.stringify({
      title: document.getElementById("todo-title").value,
      body: document.getElementById("todo-body").value,
      userId: 1,
    }),
    headers: {
      "Content-type": "application/json; charset=UTF-8",
    },
  })
    .then((response) => response.json())
    .then((json) => {
      const getTodos = fetchTodo(); //STORING PROMISE RETURN by GETTODO
      let allTodos = createTodoTemplate(json.title, json.body);
      getTodos.then((posts) => {
        /*for(let i=0; i<10; i++){
allTodos += createTodoTemplate(posts[i].title, posts[i].body);
}
*/

        for (let post of posts) {
          allTodos += createTodoTemplate(post.title, post.body);
        }
        todos.innerHTML = allTodos;
      });
    });
}

function createTodoTemplate(title, body) {
  const template = `<div class="col-4">
    <div class="card" style="width: 18rem;">
        <div class="card-body">
          <h5 class="card-title">${title}</h5>
          <p class="card-text">${body}</p>
        </div>
      </div>
  </div>`;
  return template;
}
function fetchTodo() {
  //RETUTNING PROMISE
  return fetch("https://jsonplaceholder.typicode.com/posts").then((response) =>
    response.json()
  );
}
