let fs = require("fs");
const { serialize } = require("v8");
let data = fs.readFileSync("C:/Users/ASUS/OneDrive/Desktop/10x/input.txt", 'utf-8');
let idx = 0;
data = data.split('\n');

function readLine() {
    idx++;
    return data[idx - 1].trim();
}

let arr = readLine().split(" ").map(Number);
let set = new Set();
set.add(arr[0]);
for (let i = 1; i < arr.length; i++) {
    if (!set.has(arr[i])) {
        set.add(arr[i])
    }
}
console.log(...set)

// input:
// 1 2 3 5 1 5 9 1 2 8

// output:
// 1 2 3 5 9 8