const input = document.querySelector("#todo-input");
const button = document.querySelector("#add-todo").addEventListener("click", addList);

function addList() {
    const ul = document.querySelector("#todo-holder");
    const list = document.createElement("li");
    list.classList.add("new-item");
    list.innerText = input.value;
    ul.appendChild(list);
    input.value = "";
}