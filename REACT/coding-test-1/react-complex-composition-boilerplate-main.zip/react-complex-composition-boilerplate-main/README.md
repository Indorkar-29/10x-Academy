# React Complex composition

In <code>src/components/App.js</code>,
there are 2 components apart from <code>App</code>
1) <code>Fruits</code>
2) <code>TypesOfFruits</code>

Your task is to render <code>TypesOfFruits</code> inside <code>Fruits</code>
and render <code>Fruits</code> inside <code>App</code> in their respective divs without
changing any div id.

