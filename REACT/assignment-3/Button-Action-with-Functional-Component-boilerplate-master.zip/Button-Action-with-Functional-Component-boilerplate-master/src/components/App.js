import React, {Component, useState} from "react";
import "./../styles/App.css";
import Button from "./Button";
function App() {
  return (
    <div id="main">
      {/* //Do not alter the main div */}
      <Button/>
    </div>
  );
}
export default App;