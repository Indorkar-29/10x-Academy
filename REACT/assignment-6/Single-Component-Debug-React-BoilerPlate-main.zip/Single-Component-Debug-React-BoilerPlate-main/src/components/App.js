import React from "react";
import '../styles/App.css';

function App(){
    return (
        <p>Now I can render any React component on any DOM node I want using ReactDOM.render</p>
    )
}

export default App
