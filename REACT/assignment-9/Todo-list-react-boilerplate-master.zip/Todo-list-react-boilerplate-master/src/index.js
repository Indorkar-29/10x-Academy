import React from "react";
import ReactDOM from "react-dom";
import App from "./components/App";
import Xyz from "./components/xyz";

ReactDOM.render(<App />, document.getElementById("root"));

ReactDOM.render(<Xyz/>, document.getElementById("root"));