# Easy Context

In this project, you will be practising the React Context.
Create a context in App.js and use its Provider to wrap the 
<code>UserProfile</code> component. To provider pass this object
<code>{name:"Newton",age:3}</code>.
That's all the code to write in App.js file.

In UserProfile.js use the data from context using hook,
And display it in 2 <code>h1</code> tags with id="name" and "age".

h1#name should display "Name:- Newton"
and h1#age should display "Age:- 3".