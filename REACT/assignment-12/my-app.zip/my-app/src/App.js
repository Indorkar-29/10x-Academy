import './App.css';
import { PostView } from './Layout-pages/postview';

function App() {
  return (
    <div className="App">
      <PostView/>
    </div>
  );
}

export default App;
