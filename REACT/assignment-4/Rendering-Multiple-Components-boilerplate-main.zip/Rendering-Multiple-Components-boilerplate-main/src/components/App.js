import React, {Component, useState} from "react";
import '../styles/App.css';
import { DreamProject } from "./DremProject";
const App = () => {
  return (
    <div id="main">
      <DreamProject/>
    </div>
  )
}
export default App;
