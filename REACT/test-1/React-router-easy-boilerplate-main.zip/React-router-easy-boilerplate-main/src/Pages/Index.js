import React from 'react'

export const Index = () =>{
    return (
     <div id='index-page'>Index Page</div>
    )
}