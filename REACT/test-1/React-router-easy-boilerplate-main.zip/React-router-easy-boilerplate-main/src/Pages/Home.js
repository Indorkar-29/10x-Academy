import React from 'react';

export const Home = () => {
    return (
        <div id='home-page'>Home Page</div>
    )
}