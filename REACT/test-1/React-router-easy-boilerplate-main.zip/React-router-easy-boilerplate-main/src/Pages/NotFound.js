import React from 'react';

export const NotFound = () => {
    return (
       <div id='not-found-page'>Not found page</div>
    )
}