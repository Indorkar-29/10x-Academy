import React from "react";
import ReactDOM from "react-dom";
import App from "./components/App";
function generateCodeFromObject(obj){
    //return a code generated string
    return JSON.stringify(obj);
   }
   
export default generateCodeFromObject;


ReactDOM.render(<App />, document.getElementById("root"));