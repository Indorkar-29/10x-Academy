import React from "react";
export function Div(){
    return (
        <div id="root">
            <p>I am learning React. My life is getting better.</p>
        </div>
    )
}