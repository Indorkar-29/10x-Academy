import React, {Component, useState} from "react";
import '../styles/App.css';
import { Div } from "./Div";
const App = () => {
  return (
    <div id="main"><Div/></div>
  )
}


export default App;
