console.log("Hello",process.env.USERNAME);

// set USERNAME=Tushar
// node readEnvVariable.js