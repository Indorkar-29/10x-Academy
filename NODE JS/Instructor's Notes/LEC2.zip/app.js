// let firstName = process.argv[2];
// let lastName = process.argv[3];


// console.log(process.argv);

// console.log(firstName + " " + lastName);

// process.env.NODE_ENV = "production";

// if (process.env.NODE_ENV == "development") {
//     console.log("Connect to development database");

// }else {
//     console.log("Connect to Production database");
// }

console.log(process.env.APIKEYS);