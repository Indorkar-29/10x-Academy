const express = require("express");
const mongoose = require("mongoose");
mongoose.connect("mongodb://localhost/USERDBMONGOOSE");
const userRoutes = require("./routes/user");
const loginRoutes = require("./routes/login");

const app = express();
// app.use(bodyparser.json());

app.use("/api/v1/users", userRoutes);

app.use("/api/v1/users", loginRoutes);

// CRUD CREATE READ UPDATE DELETE
// READ GET -- READ operation

app.get("*", (req, res) => {
    res.status(404).send("API NOT FOUND");
});

app.listen(5000, () => console.log("Th server is up at port 5000"));

