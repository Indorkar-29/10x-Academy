let USERNAME= process.env.name;
console.log("Hello "+USERNAME);
