const mongoose = require('mongoose');
const faker = require("faker");

async function main() {
  // Use connect method to connect to the server

  await mongoose.connect('mongodb://localhost/USERDBMONGOOSE');
  console.log('Connected successfully to server');

  const Schema = mongoose.Schema;
  const ObjectId = Schema.ObjectId;

  const userSchema =  new Schema({
    name : {type: String, required: true},
    email: {type: String, unique: true},
    age: Number,
    minor: Boolean
  })

  const User = mongoose.model('User', userSchema);
  try{
    const user = await User.create({
      name: "Ajeet",
      email: "ajeetvdfdfsdg@gmail.com",
      age: 15,
      minor : true
    })
    
    console.log(user);
  
  }catch(e){
    console.log(e.message);
  }


  return 'done.';
}

main()
  .then(console.log)
  .catch(console.error)
  .finally(() => mongoose.disconnect());