import React from 'react'
import Items from './components/Items';

const App = () => {
  return (
    <div>
      <Items/>
    </div>
  )
}

export default App;