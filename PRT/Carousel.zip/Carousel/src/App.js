import React from 'react'
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';

const App = () => {
  return (
      <Carousel>
      <div>
      <img src='/img/Goku.png' alt='img' />
      </div>
      <div>
      <img src='/img/DBZ-super.jpg' alt='img' />
      </div>
      <div>
      <img src='/img/dragon-ball black.jpg' alt='img' />
      </div>
      <div>
      <img src='/img/son-goku-dragon-ball-ultra-instinct.jpg' alt='img' />
      </div>
    </Carousel>
  )
}

export default App;