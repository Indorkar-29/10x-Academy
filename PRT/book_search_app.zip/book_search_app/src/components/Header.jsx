import React from 'react';
import './Header.css';

const Header = () => {
  return (
    <nav className='nav-bar'>
        BOOK SEARCH
    </nav>
  )
}

export default Header;