import React, { useState } from 'react'
import "./App.css";

const App = () => {
  const [details,setDetails]=useState({name:"Yusuf",age:20,gender:"none",occupation:"none",isCool:false});

  return (
    <div className='main'>
      <p>{"{"}"name":"{details.name}","age":{details.age},"gender":"{details.gender}","occupation":"{details.occupation}","isCool":{details.isCool?"true":"false"}{"}"}</p>

      <label htmlFor='name'>Name:</label>
      <input className='inp' name='name' value={details.name} type="text" onChange={(e)=>{setDetails({...details,name:e.target.value})}} />

      <label htmlFor='age'>Age:</label>
      <input className='inp' name='age' value={details.age} type="number" onChange={(e)=>{setDetails({...details,age:e.target.value})}} />

      <p>Gender:</p>
      <input type="radio" onClick={()=>{setDetails({...details,gender:"Male"})}} name="gender" value="Male" />
      <label htmlFor='male'>Male</label>
      <input type="radio" onClick={()=>{setDetails({...details,gender:"Female"})}} name="gender" value="Female"/>
      <label htmlFor='female'>Female</label>
      <input type="radio" onClick={()=>{setDetails({...details,gender:"Other"})}} name="gender" value="Other" />
      <label htmlFor='other'>Other</label>

      <label className='occ' htmlFor='occupation'>Occupation:</label>
      <select name="occupation" onChange={(e)=>{setDetails({...details,occupation:e.target.value})}}>
        <option value="none">--SELECT--</option>
        <option value="Frontend" >Frontend</option>
        <option value="Backend" >Backend</option>
        <option value="Full Stack" >Full Stack</option>
      </select>

      <p>Are you cool?</p>
      <input type="checkbox" onClick={()=>{setDetails({...details,isCool:!details.isCool})}} name="isCool" value="false" />
      <label htmlFor='isCool' >Of course I'm cool!</label>
    </div>
  )
}

export default App;