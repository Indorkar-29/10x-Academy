import React, { useState } from 'react';
import "./App.css"

const App = () => {
  const [temp,setTemp]=useState(10);
  const [background,setBackground]=useState("cold");

  const increaseTemp=()=>{
    if(temp===30) return;
    let newTemp=temp+1;
    if(newTemp >=15){
      setBackground('hot');
    }
    setTemp(newTemp);
  }

  const decreaseTemp=()=>{
    if(temp===0)return;
    let newTemp=temp-1;
    if(newTemp<15){
      setBackground('cold');
    }
    setTemp(newTemp);
  }

  return (
    <div className='main'>
      <div className='temp'>
        <div className={`deg ${background}`}>{temp}°C</div>
        <div className='block'>
          <button onClick={()=>{increaseTemp()}} className='add'>+</button>
          <button onClick={()=>{decreaseTemp()}} className='sub'>-</button>
        </div>
      </div>
    </div>
  )
}

export default App;