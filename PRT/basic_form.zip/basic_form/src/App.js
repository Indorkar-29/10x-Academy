import React, { useState } from 'react';
import "./App.css";

const App = () => {
  const [success,setSuccess]=useState(false);
  const [firstName,setFirstName]=useState("");
  const [lastName,setLastName]=useState("");
  const [email,setEmail]=useState("");
  const [firstNameError,setFirstNameError]=useState(false);
  const [lastNameError,setLastNameError]=useState(false);
  const [emailError,setEmailError]=useState(false);

  const handleFirstName=(e)=>{
    setFirstName(e.target.value);
    if(firstName.length>0){
      setFirstNameError(false);
    }
  }

  const handleLastName=(e)=>{
    setLastName(e.target.value);
    if(lastName.length>0){
      setLastNameError(false);
    }
  }

  const handleEmail=(e)=>{
    setEmail(e.target.value);
    if(email.length>0){
      setEmailError(false);
    }
  }

  const handleClick=(e)=>{
    e.preventDefault();

    if(firstName.length>0){
      setFirstNameError(false);
      if(lastName.length>0){
        setLastNameError(false);
        if(email.length>0){
          setEmailError(false);
          setSuccess(true);
        }
      }
    }
    if(firstName.length===0){
      setFirstNameError(true);
    }
    if(lastName.length===0){
      setLastNameError(true);
    }
    if(email.length===0){
      setEmailError(true);
    }
  }

  return (
    <div className='main'>
      <div className='box'>
        {success && <p className='success'>Successful! Thank you for registering</p>}
        <input type="text" className='top' onChange={handleFirstName} placeholder='First Name'/>
        {firstNameError && <p style={{color:"red",margin:"auto 40px"}}>Please enter a first name</p>}
        <input type="text" onChange={handleLastName} placeholder='Last Name'/>
        {lastNameError && <p style={{color:"red",margin:"auto 40px"}}>Please enter a last name</p>}
        <input type="email" onChange={handleEmail} placeholder='Email'/>
        {emailError && <p style={{color:"red",margin:"auto 40px"}}>Please enter an email address</p>}
        <button onClick={handleClick}>Register</button>
      </div>
    </div>
  )
}

export default App;