import React, { useEffect, useState } from 'react';
import "./Contact.css";

const Contact = () => {

    const [details,setDetails]=useState([]);

    const [age,setAge]=useState({});

    useEffect(()=>{
        fetch("https://dummyjson.com/users")
        .then((res)=>res.json())
        .then((data)=>setDetails(data.users))
        .catch((err)=>console.log(err));
    },[]);

    const handleClick=(id)=>{
      setAge({...age,[id]:!age[id]});
    }

  return (
    <>
    {details && 
    details.map((data)=>{
      return (
        <div className='contact' key={data.id}>
          <img className='img' src={data.image} alt='img' />
          <div className='box'>
            <h3 className='name'>Name: {data.firstName} {data.lastName}</h3>
            <h3 className='email'>Email: {data.email}</h3>
            <button className='btn' onClick={()=>{handleClick(data.id)}} >Toggle Age</button>
            <h3 className='age' style={{display:age[data.id]?"block":"none"}} >{data.age}</h3>
          </div>
        </div>
      )
    })
    }
    </>
  )
}

export default Contact;