import Contact from './components/Contact';

function App() {

  return (
    <div className='main'>
      <h1 style={{textAlign:"center"}}>Contact List</h1>
      <Contact/>
    </div>
  );
}

export default App;
